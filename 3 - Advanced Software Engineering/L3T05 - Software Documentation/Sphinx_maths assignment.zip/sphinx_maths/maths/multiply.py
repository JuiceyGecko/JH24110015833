def multiply_nums(num1, num2):
    """This method will be used to multiply two numbers
    
    :param num1: The first factor
    :type num1: float
    :param num2: The second factor
    :type num2: float
    :return: The product of the two numbers
    :rtype: float
    """
    return num1 * num2
