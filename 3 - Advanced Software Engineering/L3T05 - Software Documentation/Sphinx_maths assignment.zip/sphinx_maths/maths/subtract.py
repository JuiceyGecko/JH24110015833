def subtract_nums(num1, num2):
    """This method will be used to subtract two numbers
    
    :param num1: The minuend (number to subtract from)
    :type num1: float
    :param num2: The subtrahend (number to subtract)
    :type num2: float
    :return: The difference between the two numbers
    :rtype: float
    """
    return num1 - num2