def divide_nums(num1, num2):
    """This method will be used to divide two numbers
    
    :param num1: The numerator (dividend)
    :type num1: float
    :param num2: The denominator (divisor)
    :type num2: float
    :raises ZeroDivisionError: If num2 is zero
    :return: The quotient of the two numbers
    :rtype: float
    """
    return num1 / num2