def get_valid_input():
    while True:
        user_input = input("Enter your message (cannot be empty): ")
        if user_input.strip():  # Check if not empty
            return user_input
        print("Error: Input cannot be empty!")

print(f"You said: {get_valid_input()}")
